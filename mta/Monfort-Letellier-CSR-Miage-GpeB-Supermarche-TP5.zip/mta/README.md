#Instructions pour build le projet

Deziper dans dossier personnels
Import Existing Maven Project dans l'IDE


#Instructions pour l'execution du projet

Pour tester la partie A executer le main de la classe Supermarche.java
	->variables finales modifiables (rayons/stock max/nombre de chariot)
	->actions des threads observables dans la console de l'IDE

Pour la partie B executer le main de la classe Main.java
	->lancer dans un navigateur l'uri suivante : "http://localhost:5001/supermarche"
	->Ajoutez un nombre de client
	->Supermarche observables aussi dans la console de l'IDE
	->URI dispos : 	http://localhost:5001/supermarche/clients
					http://localhost:5001/supermarche/clients/x/
					http://localhost:5001/supermarche/stock/